package day4;

public interface Calculator {
	
	 void add(int x,int y);
	 void sub(int x,int y);
	 void mul(int x,int y);
	 void div(int x,int y);
	 
	 

}
