package day3;

public class City {
	
	String name;
	int pinCode;
	public City(String name, int pinCode) {
		this.name = name;
		this.pinCode = pinCode;
	}
	
	
	

}
